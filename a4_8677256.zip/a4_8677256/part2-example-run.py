Python 3.4.3 (v3.4.3:9b73f1c3e601, Feb 23 2015, 02:52:03) 
[GCC 4.2.1 (Apple Inc. build 5666) (dot 3)] on darwin
Type "copyright", "credits" or "license()" for more information.
>>> ================================ RESTART ================================
>>> 



===================================================
What would you like to do? Enter 1, 2, 3, 4, 5, 6 or Q for answer.
1: Look up year range
2: Look up month/year
3: Search for author
4: Search for title
5: Number of authors with at least x bestsellers
6: List y authors with the most bestsellers
Q: Quit
===================================================
Answer (1,2,3, 4, 5, 6, Q or q): aha
If you answer is not Q or q, then it must be an integer.
Invalid input, try again
Answer (1,2,3, 4, 5, 6, Q or q): 10
Invalid input, try again
Answer (1,2,3, 4, 5, 6, Q or q): jooj
If you answer is not Q or q, then it must be an integer.
Invalid input, try again
Answer (1,2,3, 4, 5, 6, Q or q): 1
Enter beginning year: 1972
Enter ending year: 1973
The Winds of War, by Herman Wouk (1972-01-23)
The Game of the Foxes, by Ladislas Farago (1972-03-19)
The Word, by Irving Wallace (1972-05-14)
The Boys of Summer, by Roger Kahn (1972-05-28)
I'm OK, You're OK, by Thomas Harris (1972-06-25)
Jonathan Livingston Seagull, by Richard Bach (1972-07-02)
O Jerusalem!, by Larry Collins (1972-07-23)
Harry S. Truman, by Margaret Truman (1973-01-14)
The Best and the Brightest, by David Halberstam (1973-01-21)
Dr. Atkins' Diet Revolution, by Robert C. Atkins (1973-02-18)
The Odessa File, by Frederick Forsyth (1973-03-25)
Once Is Not Enough, by Jacqueline Susann (1973-05-06)
Breakfast of Champions, by Kurt Vonnegut (1973-07-01)
The Joy of Sex, by Alex Comfort (1973-08-05)
The Hollow Hills, by Mary Stewart (1973-09-09)
How to Be Your Own Best Friend, by Mildred Newman (1973-10-14)
The Honorary Consul, by Graham Greene (1973-11-25)
Alistair Cooke's America, by Alistair Cooke (1973-12-09)
Burr, by Gore Vidal (1973-12-09)

Press enter to continue. 




===================================================
What would you like to do? Enter 1, 2, 3, 4, 5, 6 or Q for answer.
1: Look up year range
2: Look up month/year
3: Search for author
4: Search for title
5: Number of authors with at least x bestsellers
6: List y authors with the most bestsellers
Q: Quit
===================================================
Answer (1,2,3, 4, 5, 6, Q or q): 1
Enter beginning year: lasj
Please give a four digit integer for the year.
999
Please give a four digit integer for the year.
-100
Please give a four digit integer for the year.
1000
Enter ending year: 1001
No books found in that range of years.

Press enter to continue. 




===================================================
What would you like to do? Enter 1, 2, 3, 4, 5, 6 or Q for answer.
1: Look up year range
2: Look up month/year
3: Search for author
4: Search for title
5: Number of authors with at least x bestsellers
6: List y authors with the most bestsellers
Q: Quit
===================================================
Answer (1,2,3, 4, 5, 6, Q or q): 1
Enter beginning year: 1999
Enter ending year: 1997
No books found in that range of years.

Press enter to continue. 




===================================================
What would you like to do? Enter 1, 2, 3, 4, 5, 6 or Q for answer.
1: Look up year range
2: Look up month/year
3: Search for author
4: Search for title
5: Number of authors with at least x bestsellers
6: List y authors with the most bestsellers
Q: Quit
===================================================
Answer (1,2,3, 4, 5, 6, Q or q): 2
Enter month (as an integer, 1-12): 0
Invalid month. Must be interger, 1-12. Try again
Enter month (as an integer, 1-12): jooooj
Month must be an integer.
Invalid month. Must be interger, 1-12. Try again
Enter month (as an integer, 1-12): -10
Invalid month. Must be interger, 1-12. Try again
Enter month (as an integer, 1-12): 4.5
Month must be an integer.
Invalid month. Must be interger, 1-12. Try again
Enter month (as an integer, 1-12): 5
Enter year: 999
Please give a four digit integer for the year.
1999
All Titles in month 5 of 1999:
The Girl Who Loved Tom Gordon, by Stephen King (1999-05-02)
We'll Meet Again, by Mary Higgins Clark (1999-05-09)
Star Wars Episode IThe Phantom Menace, by Terry Brooks (1999-05-23)

Press enter to continue. 




===================================================
What would you like to do? Enter 1, 2, 3, 4, 5, 6 or Q for answer.
1: Look up year range
2: Look up month/year
3: Search for author
4: Search for title
5: Number of authors with at least x bestsellers
6: List y authors with the most bestsellers
Q: Quit
===================================================
Answer (1,2,3, 4, 5, 6, Q or q): 2
Enter month (as an integer, 1-12): 12
Enter year: 2012
All Titles in month 12 of 2012:
The Last Man, by Vince Flynn (2012-12-02)
Notorious Nineteen, by Janet Evanovich (2012-12-09)
Cold Days, by Jim Butcher (2012-12-16)
Threat Vector, by Tom Clancy with Mark Greaney (2012-12-23)

Press enter to continue. 




===================================================
What would you like to do? Enter 1, 2, 3, 4, 5, 6 or Q for answer.
1: Look up year range
2: Look up month/year
3: Search for author
4: Search for title
5: Number of authors with at least x bestsellers
6: List y authors with the most bestsellers
Q: Quit
===================================================
Answer (1,2,3, 4, 5, 6, Q or q): 3
Enter an author's name (or part of a name): King
Mine Enemy Grows Older, by Alexander King (1959-04-12)
May This House Be Safe from Tigers, by Alexander King (1960-03-13)
The Dead Zone, by Stephen King (1979-10-14)
Firestarter, by Stephen King (1980-09-28)
Cujo, by Stephen King (1981-08-23)
Different Seasons, by Stephen King (1982-08-15)
Pet Sematary, by Stephen King (1983-11-13)
The Talisman, by Stephen King (1984-10-28)
Thinner, by Stephen King (1985-04-28)
Skeleton Crew, by Stephen King (1985-06-23)
It, by Stephen King (1986-09-14)
The Eyes of the Dragon, by Stephen King (1987-02-01)
Misery, by Stephen King (1987-06-07)
The Tommyknockers, by Stephen King (1987-11-29)
A Brief History of Time, by Stephen Hawking (1988-06-26)
The Dark Half, by Stephen King (1989-11-05)
The Stand, by Stephen King (1990-05-13)
Four Past Midnight, by Stephen King (1990-09-16)
Gerald's Game, by Stephen King (1992-07-19)
Dolores Claiborne, by Stephen King (1992-12-06)
Insomnia, by Stephen King (1994-10-23)
Desperation, by Stephen King (1996-10-13)
Bag of Bones, by Stephen King (1998-10-11)
The Girl Who Loved Tom Gordon, by Stephen King (1999-05-02)
Dreamcatcher, by Stephen King (2001-04-08)
Black House, by Stephen King (2001-09-30)
Everything's Eventual, by Stephen King (2002-04-07)
From a Buick 8, by Stephen King (2002-10-13)
Song of Susannah, by Stephen King (2004-06-27)
The Dark Tower, by Stephen King (2004-10-10)
Cell, by Stephen King (2006-02-12)
Lisey's Story, by Stephen King (2006-11-12)
Duma Key, by Stephen King (2008-02-10)
Under the Dome, by Stephen King (2009-11-29)
The Grand Design, by Stephen Hawking (2010-09-26)
23337, by Stephen King (2011-11-27)
The Wind Through the Keyhole, by Stephen King (2012-05-13)
Doctor Sleep, by Stephen King (2013-10-13)

Press enter to continue. 




===================================================
What would you like to do? Enter 1, 2, 3, 4, 5, 6 or Q for answer.
1: Look up year range
2: Look up month/year
3: Search for author
4: Search for title
5: Number of authors with at least x bestsellers
6: List y authors with the most bestsellers
Q: Quit
===================================================
Answer (1,2,3, 4, 5, 6, Q or q): ah
If you answer is not Q or q, then it must be an integer.
Invalid input, try again
Answer (1,2,3, 4, 5, 6, Q or q): 3
Enter an author's name (or part of a name): ah
Earth and High Heaven, by Gwethalyn Graham (1945-04-22)
Kon-Tiki, by Thor Heyerdahl (1950-10-08)
Tallulah, by Tallulah Bankhead (1952-10-26)
Aku-Aku, by Thor Heyerdahl (1958-10-19)
The Boys of Summer, by Roger Kahn (1972-05-28)
The Honorary Consul, by Graham Greene (1973-11-25)
Donahue, by Phil Donahue (1980-03-23)
Heir to the Empire, by Timothy Zahn (1991-06-30)
Personal History, by Katharine Graham (1997-02-23)
Just As I Am, by Billy Graham (1997-06-29)
Indwelling, by Tim LaHaye (2000-06-11)
The Mark, by Tim LaHaye (2000-12-03)
Desecration, by Tim LaHaye (2001-11-18)
The Remnant, by Tim LaHaye (2002-07-21)
Armageddon, by Tim LaHaye (2003-04-27)
Glorious Appearing, by Tim LaHaye (2004-04-18)
The Rising, by Tim LaHaye (2005-04-03)
A Long Way Gone, by Ishmael Beah (2007-04-15)
Power to the People, by Laura Ingraham (2007-09-30)
Liberal Fascism, by Jonah Goldberg (2008-03-09)
Unaccustomed Earth, by Jhumpa Lahiri (2008-04-20)
Going Rogue, by Sarah Palin (2009-12-06)
The Obama Diaries, by Laura Ingraham (2010-08-01)
Home Front, by Kristin Hannah (2012-02-19)
The Storm, by Clive Cussler and Graham Brown (2012-06-17)
Shadow of Night, by Deborah Harkness (2012-07-29)

Press enter to continue. 




===================================================
What would you like to do? Enter 1, 2, 3, 4, 5, 6 or Q for answer.
1: Look up year range
2: Look up month/year
3: Search for author
4: Search for title
5: Number of authors with at least x bestsellers
6: List y authors with the most bestsellers
Q: Quit
===================================================
Answer (1,2,3, 4, 5, 6, Q or q): 3
Enter an author's name (or part of a name): lasjdfl
No books found by an author whose name contains: lasjdfl

Press enter to continue. 




===================================================
What would you like to do? Enter 1, 2, 3, 4, 5, 6 or Q for answer.
1: Look up year range
2: Look up month/year
3: Search for author
4: Search for title
5: Number of authors with at least x bestsellers
6: List y authors with the most bestsellers
Q: Quit
===================================================
Answer (1,2,3, 4, 5, 6, Q or q): 4
Enter a title (or part of a title): secret
The Secret of Santa Vittoria, by Robert Crichton (1966-11-20)
The Secret Pilgrim, by John le Carre (1991-01-20)
Harry Potter and the Chamber of Secrets, by J. K. Rowling (1999-06-20)

Press enter to continue. 




===================================================
What would you like to do? Enter 1, 2, 3, 4, 5, 6 or Q for answer.
1: Look up year range
2: Look up month/year
3: Search for author
4: Search for title
5: Number of authors with at least x bestsellers
6: List y authors with the most bestsellers
Q: Quit
===================================================
Answer (1,2,3, 4, 5, 6, Q or q): 4
Enter a title (or part of a title): scary
No books found with title that contains: scary

Press enter to continue. 




===================================================
What would you like to do? Enter 1, 2, 3, 4, 5, 6 or Q for answer.
1: Look up year range
2: Look up month/year
3: Search for author
4: Search for title
5: Number of authors with at least x bestsellers
6: List y authors with the most bestsellers
Q: Quit
===================================================
Answer (1,2,3, 4, 5, 6, Q or q): 5
Enter an integer bigger than zero: 4.5
Number must be an integer.
Number must be at least one. Try again
Enter an integer bigger than zero: 88.99
Number must be an integer.
Number must be at least one. Try again
Enter an integer bigger than zero: asljf
Number must be an integer.
Number must be at least one. Try again
Enter an integer bigger than zero: -10
Number must be at least one. Try again
Enter an integer bigger than zero: -10000
Number must be at least one. Try again
Enter an integer bigger than zero: 14
The list of authors with at least 14 NYT bestsellers is: 
1. James Patterson with 42 bestsellers
2. Stephen King with 34 bestsellers
3. Danielle Steel with 28 bestsellers
4. John Grisham with 25 bestsellers
5. Janet Evanovich with 19 bestsellers
6. Mary Higgins Clark with 18 bestsellers
7. Patricia Cornwell with 17 bestsellers
8. Tom Clancy with 16 bestsellers

Press enter to continue. 




===================================================
What would you like to do? Enter 1, 2, 3, 4, 5, 6 or Q for answer.
1: Look up year range
2: Look up month/year
3: Search for author
4: Search for title
5: Number of authors with at least x bestsellers
6: List y authors with the most bestsellers
Q: Quit
===================================================
Answer (1,2,3, 4, 5, 6, Q or q): 5
Enter an integer bigger than zero: 18
The list of authors with at least 18 NYT bestsellers is: 
1. James Patterson with 42 bestsellers
2. Stephen King with 34 bestsellers
3. Danielle Steel with 28 bestsellers
4. John Grisham with 25 bestsellers
5. Janet Evanovich with 19 bestsellers
6. Mary Higgins Clark with 18 bestsellers

Press enter to continue. 




===================================================
What would you like to do? Enter 1, 2, 3, 4, 5, 6 or Q for answer.
1: Look up year range
2: Look up month/year
3: Search for author
4: Search for title
5: Number of authors with at least x bestsellers
6: List y authors with the most bestsellers
Q: Quit
===================================================
Answer (1,2,3, 4, 5, 6, Q or q): 5
Enter an integer bigger than zero: 30
The list of authors with at least 30 NYT bestsellers is: 
1. James Patterson with 42 bestsellers
2. Stephen King with 34 bestsellers

Press enter to continue. 




===================================================
What would you like to do? Enter 1, 2, 3, 4, 5, 6 or Q for answer.
1: Look up year range
2: Look up month/year
3: Search for author
4: Search for title
5: Number of authors with at least x bestsellers
6: List y authors with the most bestsellers
Q: Quit
===================================================
Answer (1,2,3, 4, 5, 6, Q or q): 5
Enter an integer bigger than zero: 100
The list of authors with at least 100 NYT bestsellers is: 

Press enter to continue. 




===================================================
What would you like to do? Enter 1, 2, 3, 4, 5, 6 or Q for answer.
1: Look up year range
2: Look up month/year
3: Search for author
4: Search for title
5: Number of authors with at least x bestsellers
6: List y authors with the most bestsellers
Q: Quit
===================================================
Answer (1,2,3, 4, 5, 6, Q or q): 6
Enter an integer bigger than zero: 0
Number must be at least one. Try again
Enter an integer bigger than zero: 4.5
Number must be an integer.
Number must be at least one. Try again
Enter an integer bigger than zero: 3
Top 3 authors by the number of NYT bestsellers is: 
1. James Patterson
2. Stephen King
3. Danielle Steel

Press enter to continue. 




===================================================
What would you like to do? Enter 1, 2, 3, 4, 5, 6 or Q for answer.
1: Look up year range
2: Look up month/year
3: Search for author
4: Search for title
5: Number of authors with at least x bestsellers
6: List y authors with the most bestsellers
Q: Quit
===================================================
Answer (1,2,3, 4, 5, 6, Q or q): 6
Enter an integer bigger than zero: 20
Top 20 authors by the number of NYT bestsellers is: 
1. James Patterson
2. Stephen King
3. Danielle Steel
4. John Grisham
5. Janet Evanovich
6. Mary Higgins Clark
7. Patricia Cornwell
8. Tom Clancy
9. David Baldacci
10. Bob Woodward
11. Nora Roberts
12. Dean R. Koontz
13. Sue Grafton
14. James Michener
15. Sidney Sheldon
16. Robert Ludlum
17. Tim LaHaye
18. Nicholas Sparks
19. Michael Connelly
20. Lee Child

Press enter to continue. 




===================================================
What would you like to do? Enter 1, 2, 3, 4, 5, 6 or Q for answer.
1: Look up year range
2: Look up month/year
3: Search for author
4: Search for title
5: Number of authors with at least x bestsellers
6: List y authors with the most bestsellers
Q: Quit
===================================================
Answer (1,2,3, 4, 5, 6, Q or q): q
>>> 
